package com.simplilearn.diamond;

public interface First {
	default void show() {
		System.out.println("Default First");
	}
}
