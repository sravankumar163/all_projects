package com.sra1;

public class App {
	pub;ic String returnSomthing() {
		return "Dummy";
	}

}
