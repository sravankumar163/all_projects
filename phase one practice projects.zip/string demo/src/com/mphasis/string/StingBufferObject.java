package com.mphasis.string;

public class StingBufferObject {

	public static void main(String[] args)
	{
		
		StringBuffer sb1 = new StringBuffer("java");
		
		StringBuffer sb2 = new StringBuffer("Langauge");
		
		//sb2.reverse();
		
		System.out.println(sb2);
		System.out.println(sb1);
		System.out.println(sb2);
		
		
		sb1.append(sb2);
		
		System.out.println(sb2);
		
		String s1 = new String("Sravan");
		
		StringBuilder sbd1 = new StringBuilder(s1);
		String str2 = sb2.toString();
		//tostring() covert srting into object
		

	}

}
