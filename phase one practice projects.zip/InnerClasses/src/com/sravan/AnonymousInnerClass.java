package com.sravan;

abstract class AnonymousInnerClass {
	public abstract void display();
}
