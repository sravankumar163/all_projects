package com.simplilearn.LinkedList;

public class Main {
	public static void main(String[] args) 
	{
DLL dll = new DLL
dll.append(6); 
dll.push(7);
dll.push(1); 
dll.append(4); 
dll.InsertAfter(dll.head.next, 8); 
		System.out.println("Created DLL is: "); 
    		dll.printlist(dll.head); 
	}

}


