package first;

public class Demo
{

	public static void main(String[] args) 
	{
		System.out.println("test car");
	
			System.out.println("main starts.....");
			System.out.println("main ends......");

	}

}
