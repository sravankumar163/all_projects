package com.sravan;

public class defAccessSpecifier {

	void display() {
		System.out.println("You are using defalut access specifier");
	}
}
