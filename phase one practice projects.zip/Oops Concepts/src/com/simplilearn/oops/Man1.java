package com.simplilearn.oops;

public class Man1 {
	String name; 
    String study; 
    int age; 
    String color; 
    public Man1(String string, String string2, int i, String string3) {
		
	}
	public void Man(String name, String study, int age, String color) 
    { 
        this.name = name; 
        this.study = study; 
        this.age = age; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return "sravan"; 
    } 
    public String getStudy() 
    { 
        return "btech"; 
    } 
    public int getAge() 
    { 
        return 21; 
    } 
    public String getColor() 
    { 
        return "gray"; 
    } 
    @Override
    public String toString() 
    { 
        return("Hi my name is  "+ this.getName()+ ".\nMy study,age and color are " + this.getStudy()+", " + this.getAge()+ ", and"+ this.getColor() + "."); 
    }
	

}
