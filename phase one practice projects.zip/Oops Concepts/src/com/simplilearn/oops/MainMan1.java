package com.simplilearn.oops;

public class MainMan1 {
	public static void main(String[] args) 
    { 
        Man1 scott = new Man1("Sravan","Btech", 21, "gray"); 
        System.out.println(scott.toString()); 
    } 
}
