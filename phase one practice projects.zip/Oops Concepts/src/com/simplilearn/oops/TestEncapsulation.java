package com.simplilearn.oops;

public class TestEncapsulation {
	public static void main (String[] args)  
    { 
        Encapsulate obj = new Encapsulate(); 
        obj.setName("Dasari Sravan"); 
        obj.setAge(21); 
        obj.setRoll(305); 
        System.out.println("My name: " + obj.getName()); 
        System.out.println("My age: " + obj.getAge()); 
        System.out.println("My roll: " + obj.getRoll());      
    }
}
